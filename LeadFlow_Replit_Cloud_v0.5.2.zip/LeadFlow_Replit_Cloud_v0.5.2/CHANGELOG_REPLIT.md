# Replit cloud packaging — v0.5.2

- Added Replit project configuration for Node.js 22.
- Configured Next.js dev and production server to bind to `0.0.0.0` and honor `PORT`.
- Added server health endpoint at `/api/health` for deployment checks.
- Added Replit-specific import, Secrets, Supabase, Google OAuth, and Autoscale publishing instructions.
- Added Replit Agent guardrails to preserve the full-stack code and prevent secrets from entering chat/source.
