# LeadFlow Cloud — Replit setup (v0.5.2)

This is the **real full-stack LeadFlow project**, not the earlier static HTML demo. It is prepared to import into Replit and run as a Next.js web service.

## What is real in this build

- Next.js server-rendered web app and API routes.
- Supabase email/password authentication and cookie sessions.
- A separate workspace provisioned for each signup.
- PostgreSQL with Row Level Security (RLS) to isolate workspace data.
- Create and update real lead records in Supabase.
- Public inquiry page per business at `/request/<workspace-slug>`.
- Google OAuth for Gmail sending and Calendar event creation (requires Google Cloud setup and user consent).
- Make/Zapier webhook integration (requires a webhook URL owned by the business).
- Optional Resend owner notifications (requires a verified sending domain and API key).

## What is not yet connected

No external provider account has been created or authorized for you. Gmail, Calendar, Make, Zapier and Resend stay unavailable until their credentials are configured. Stripe billing, team invitations, QuickBooks, Jobber, Housecall Pro and other field-service integrations are not implemented in this release. This is an early-access build, not a certified production service.

## Import this project into Replit

1. In Replit, create a **new app** and choose **Import from ZIP**.
2. Upload `LeadFlow_Replit_Cloud_v0.5.2.zip`.
3. Let Replit finish importing the files and installing packages. Do not select Static deployment: this app needs a Node.js server for authentication, API routes and integrations.
4. Press **Run**. The `.replit` file starts `npm run dev` and binds Next.js to `0.0.0.0`.
5. If Replit asks which port to expose, use the port shown in the Console (normally 3000).

Keep the previous static demo in its own Replit project until this one is working.

## Configure Supabase (required for real accounts and shared cloud data)

An adult/guardian should manage the provider account and any billing or contracts where required.

1. Create a Supabase project at https://database.new.
2. In the project, open **SQL Editor** and run the entire file `supabase/migrations/0001_initial.sql`.
3. In Supabase **Project Settings → API Keys** (or the Connect panel), copy the Project URL and the **Publishable key**.
4. In Supabase **Project Settings → API Keys**, create/copy the **Secret key** for server use. Never expose it to browser code.
5. In Replit, open **Tools → Secrets** and add:

   - `NEXT_PUBLIC_SUPABASE_URL` = Supabase Project URL
   - `NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY` = Supabase Publishable key
   - `SUPABASE_SECRET_KEY` = Supabase Secret key (server-only)
   - `NEXT_PUBLIC_SITE_URL` = the Replit development URL while testing; change to the published `https://<app-name>.replit.app` URL before production publication
   - `INTAKE_RATE_LIMIT_SECRET` = a new random string of at least 32 characters
   - `INTEGRATION_ENCRYPTION_KEY` = 64 hexadecimal characters (32 random bytes)

   Keep all secret values inside Replit Secrets. Never paste them into Replit Agent chat, this conversation, source files, or screenshots. Do not put `SUPABASE_SECRET_KEY` in a variable beginning with `NEXT_PUBLIC_`.

6. In Supabase **Authentication → URL Configuration**, set the Site URL to your Replit URL and add this redirect URL:

   `https://YOUR-APP.replit.app/auth/callback`

   While testing in Replit's workspace preview, also add the exact preview callback URL shown in your browser. Redirect URLs must match the host and path.
7. Ensure email confirmation is enabled. A new user signs up, confirms the email, then signs in. The database trigger creates that user's workspace.
8. Restart the Replit app after adding Secrets. Test signup with a test email you control, then create a fictional lead and refresh the page. The lead should still be present because it is in Supabase.

For the first core test, the three most important values are the URL, Publishable key and Secret key. The rate-limit and encryption secrets are used by public intake and integrations. Configure all six before enabling the live inquiry form or connecting providers.

## Publish online (after the preview works)

1. Open **Publishing** in Replit.
2. Choose a server deployment such as **Autoscale** (not Static). This app needs a running Node server and API routes.
3. Build command: `npm run build`
4. Run command: `npm run start`
5. Add the same environment variables to the **published deployment's Secrets**. Workspace Secrets and production deployment Secrets may be managed separately. Review the production secret list before publishing.
6. Publish and copy the resulting `https://<app-name>.replit.app` URL.
7. Update `NEXT_PUBLIC_SITE_URL` and Supabase Auth Site URL / Redirect URLs to the published URL, then republish so the app uses the final URL.

Autoscale is designed for web apps with variable traffic and provides a Replit-hosted URL. Check Replit's displayed usage and publishing costs with a parent/guardian before confirming publication.

## Turn on Google after the core app works

Google is optional. Do not configure it until signup, login and lead storage work.

1. Use an adult-managed Google Cloud project.
2. Enable Gmail API and Google Calendar API.
3. Configure the OAuth consent screen and add your test account as a test user.
4. Create a Web application OAuth client.
5. Set its Authorized redirect URI to:

   `https://YOUR-APP.replit.app/api/integrations/google/callback`

6. Add Replit Secrets `GOOGLE_CLIENT_ID`, `GOOGLE_CLIENT_SECRET`, and `GOOGLE_REDIRECT_URI` using that exact callback URL.
7. The workspace owner signs in to LeadFlow and explicitly chooses **Connect** under Google Workspace. Gmail sends only when contact permission is recorded and the user deliberately clicks Email. Calendar creates an event only after the user initiates it.

Google may require verification before unrelated users can authorize Gmail/Calendar scopes outside the test-user list.

## How to verify

- `/api/health` should return `{"status":"ok","service":"leadflow"}`.
- `/signup` should load.
- Create a test workspace with a test email you control.
- Confirm the email, sign in, create a fictional lead, and refresh the dashboard.
- Open the public request URL only after all intake secrets and bot protection are configured.

## Troubleshooting

- **`Supabase is not configured`**: add the two public Supabase values to Replit Secrets and restart.
- **Signup email link returns to the wrong site**: fix `NEXT_PUBLIC_SITE_URL` and the Supabase redirect allowlist, then restart/republish.
- **Lead can't be saved**: confirm the migration ran completely and the signed-in user has a workspace membership in `workspace_members`.
- **Published app errors but Preview works**: compare the production Deployment Secrets to Workspace Secrets and check Publishing logs.
- **Don't send credentials in chat**. Share only the error message with all keys/tokens removed.

## Safety and launch limits

Use fictional test records until an adult-managed business owner approves the privacy, data retention, and security setup. Before taking paying customers, arrange a security review, test backups/restores, configure rate-limiting/bot protection, publish a privacy notice and terms, monitor errors, and check all applicable provider rules. A parent/guardian should manage provider accounts, payment arrangements, contracts, and business registration where required.
