import { NextResponse } from 'next/server';

export const dynamic = 'force-dynamic';

export async function GET() {
  return NextResponse.json(
    { status: 'ok', service: 'leadflow', version: '0.5.2' },
    { status: 200, headers: { 'Cache-Control': 'no-store' } }
  );
}
