# Production security checklist

- [ ] Use a production Supabase project with backups enabled and perform a restore test.
- [ ] Test row-level security with two unrelated business accounts to prove tenant isolation.
- [ ] Never expose `SUPABASE_SECRET_KEY`, Google OAuth secrets, `INTEGRATION_ENCRYPTION_KEY`, `INTAKE_RATE_LIMIT_SECRET`, Stripe keys, Resend keys or webhook URLs to the browser.
- [ ] Keep the GitHub repository private before adding business-specific configuration. Never commit `.env.local` or provider secrets.
- [ ] Configure HTTPS, exact Google callback URLs, OAuth consent, test users and required verification.
- [ ] Configure Turnstile or equivalent protection on public forms.
- [ ] Test invoice token privacy, amount integrity, Stripe webhook signatures, duplicate events and failed payments.
- [ ] Use Stripe test mode first. An adult/business owner must manage the payment account, identity verification, bank details and provider agreements. Do not store card numbers in LeadFlow.
- [ ] Have the business owner verify tax calculations, invoice disclosures, refund/chargeback process and legal requirements.
- [ ] Set data retention, privacy, and customer deletion procedures.
- [ ] Test access-token refresh, Google disconnection/revocation and email delivery.
- [ ] Configure monitoring, incident response and backups before onboarding paying customers.
