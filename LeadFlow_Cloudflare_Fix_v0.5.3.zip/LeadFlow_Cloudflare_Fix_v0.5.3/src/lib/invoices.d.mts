export function validatePaymentUrl(value: string | null | undefined): { ok: true; url: string | null } | { ok: false; reason: string };
export function calculateInvoice(items: Array<{ description: string; quantity?: number; unit_price?: number; unitPrice?: number }>, taxRateInput?: number): {
  items: Array<{ description: string; quantity: number; unit_price: number; total: number }>;
  taxRate: number;
  subtotal: number;
  taxAmount: number;
  total: number;
};
