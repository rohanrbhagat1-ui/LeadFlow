import { createSupabaseAdminClient } from '@/lib/supabase/admin';
import { decryptJson, encryptJson } from '@/lib/crypto';

type StoredStripeConnection = { accountId: string; livemode: boolean };

export function getStripeConnectSetupStatus() {
  const required = [
    'STRIPE_SECRET_KEY',
    'STRIPE_CONNECT_CLIENT_ID',
    'STRIPE_CONNECT_REDIRECT_URI',
    'STRIPE_WEBHOOK_SECRET',
    'INTEGRATION_ENCRYPTION_KEY'
  ];
  const missing = required.filter((name) => !process.env[name]);
  if (!process.env.SUPABASE_SECRET_KEY && !process.env.SUPABASE_SERVICE_ROLE_KEY) {
    missing.push('SUPABASE_SECRET_KEY');
  }
  const platformKey = process.env.STRIPE_SECRET_KEY ?? '';
  if (platformKey && !platformKey.startsWith('sk_test_') && !platformKey.startsWith('sk_live_')) {
    missing.push('STRIPE_SECRET_KEY (must be a Stripe platform secret key)');
  }
  const siteUrl = (process.env.NEXT_PUBLIC_SITE_URL ?? '').replace(/\/$/, '');
  const redirectUri = process.env.STRIPE_CONNECT_REDIRECT_URI ?? '';
  if (siteUrl && redirectUri) {
    const expected = `${siteUrl}/api/integrations/stripe/callback`;
    if (redirectUri !== expected) missing.push('STRIPE_CONNECT_REDIRECT_URI (must exactly match the public callback URL)');
  }
  return { ready: missing.length === 0, missing };
}

export function getStripePlatformSecret() {
  const status = getStripeConnectSetupStatus();
  if (!status.ready) throw new Error(`Stripe Connect is not configured. Missing or mismatched settings: ${status.missing.join(', ')}.`);
  return process.env.STRIPE_SECRET_KEY!;
}

export async function saveStripeConnection(workspaceId: string, accountId: string, livemode: boolean) {
  if (!/^acct_[A-Za-z0-9]+$/.test(accountId)) throw new Error('Stripe returned an invalid connected account ID.');
  const admin = createSupabaseAdminClient();
  const { error } = await admin.from('integrations').upsert({
    workspace_id: workspaceId,
    provider: 'stripe',
    status: 'connected',
    account_email: null,
    config_ciphertext: encryptJson({ accountId, livemode } satisfies StoredStripeConnection),
    updated_at: new Date().toISOString()
  }, { onConflict: 'workspace_id,provider' });
  if (error) throw new Error('Could not securely save the business Stripe connection.');
}

export async function getConnectedStripeAccount(workspaceId: string): Promise<StoredStripeConnection | null> {
  const admin = createSupabaseAdminClient();
  const { data, error } = await admin.from('integrations')
    .select('config_ciphertext,status')
    .eq('workspace_id', workspaceId)
    .eq('provider', 'stripe')
    .eq('status', 'connected')
    .maybeSingle();
  if (error || !data?.config_ciphertext) return null;
  const value = decryptJson<StoredStripeConnection>(data.config_ciphertext);
  if (!value.accountId?.startsWith('acct_')) return null;
  return value;
}

export async function deleteStripeConnection(workspaceId: string) {
  const admin = createSupabaseAdminClient();
  const connected = await getConnectedStripeAccount(workspaceId);
  const clientId = process.env.STRIPE_CONNECT_CLIENT_ID;
  const secret = process.env.STRIPE_SECRET_KEY;
  if (connected && clientId && secret) {
    const body = new URLSearchParams({ client_id: clientId, stripe_user_id: connected.accountId });
    const basicAuth = Buffer.from(`${secret}:`, 'utf8').toString('base64');
    const response = await fetch('https://connect.stripe.com/oauth/deauthorize', {
      method: 'POST',
      headers: { 'content-type': 'application/x-www-form-urlencoded', authorization: `Basic ${basicAuth}` },
      body,
      signal: AbortSignal.timeout(10000),
      cache: 'no-store',
      redirect: 'error'
    });
    if (!response.ok) throw new Error('Stripe could not revoke the account connection. Try again or disconnect LeadFlow from the Stripe dashboard.');
  }
  const { error } = await admin.from('integrations').delete()
    .eq('workspace_id', workspaceId).eq('provider', 'stripe');
  if (error) throw new Error('Could not remove the Stripe connection from this workspace.');
}
