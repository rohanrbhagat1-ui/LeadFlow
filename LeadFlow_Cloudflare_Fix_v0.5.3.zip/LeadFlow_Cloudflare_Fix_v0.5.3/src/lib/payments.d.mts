export function createStripeCheckoutParams(invoice: {
  id: string; workspace_id: string; public_token: string; customer_email: string;
  items: Array<{ description: string; quantity: number; unit_price: number; total: number }>;
  tax_rate: number; tax_amount: number;
}, siteUrl: string): URLSearchParams;
export function verifyStripeSignature(rawBody: string, signatureHeader: string, secret: string, nowMs?: number): boolean;
