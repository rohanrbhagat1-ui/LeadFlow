'use client';

export default function PrintInvoiceButton() {
  return <button type="button" className="button secondary print-invoice-button" onClick={() => window.print()}>Print / Save PDF</button>;
}
