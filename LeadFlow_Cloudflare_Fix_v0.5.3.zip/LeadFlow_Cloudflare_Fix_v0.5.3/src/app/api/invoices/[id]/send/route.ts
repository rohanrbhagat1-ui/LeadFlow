import { NextResponse } from 'next/server';
import { google } from 'googleapis';
import { getWorkspaceContext } from '@/lib/auth';
import { createSupabaseAdminClient } from '@/lib/supabase/admin';
import { getConnectedGoogleClient } from '@/lib/google';
import { makeGmailRawMessage } from '@/lib/core.mjs';
import { getConnectedStripeAccount, getStripeConnectSetupStatus } from '@/lib/stripe-connect';

export async function POST(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const context = await getWorkspaceContext();
    if (!context?.user || !context.workspace) return NextResponse.json({ error: 'Sign in first.' }, { status: 401 });
    if (!['owner', 'admin'].includes(context.role ?? '')) return NextResponse.json({ error: 'Only a workspace owner or admin can send invoices.' }, { status: 403 });
    const stripeSetup = getStripeConnectSetupStatus();
    if (!stripeSetup.ready) return NextResponse.json({ error: `Stripe platform setup is incomplete: ${stripeSetup.missing.join(', ')}.` }, { status: 503 });
    const connectedStripe = await getConnectedStripeAccount(context.workspace.id);
    if (!connectedStripe) return NextResponse.json({ error: "Connect this business Stripe account from Integrations before sending a pay-online invoice." }, { status: 409 });
    const platformIsLive = (process.env.STRIPE_SECRET_KEY ?? '').startsWith('sk_live_');
    if (connectedStripe.livemode !== platformIsLive) return NextResponse.json({ error: 'The connected Stripe account mode does not match the platform test/live mode.' }, { status: 409 });
    const { id } = await params;
    const admin = createSupabaseAdminClient();
    const { data: invoice, error } = await admin.from('invoices').select('*')
      .eq('id', id).eq('workspace_id', context.workspace.id).maybeSingle();
    if (error || !invoice) return NextResponse.json({ error: 'Invoice not found in this workspace.' }, { status: 404 });
    if (invoice.status === 'paid') return NextResponse.json({ error: 'This invoice is already paid.' }, { status: 409 });
    if (invoice.status === 'void') return NextResponse.json({ error: 'This invoice has been voided.' }, { status: 409 });

    const siteUrl = (process.env.NEXT_PUBLIC_SITE_URL ?? '').replace(/\/$/, '');
    if (!siteUrl.startsWith('https://')) return NextResponse.json({ error: 'Set NEXT_PUBLIC_SITE_URL to your HTTPS Cloudflare Worker address.' }, { status: 503 });
    const invoiceUrl = `${siteUrl}/invoice/${invoice.public_token}`;
    const { client } = await getConnectedGoogleClient(context.workspace.id);
    const gmail = google.gmail({ version: 'v1', auth: client });
    const currency = new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' });
    const lineSummary = (invoice.items as Array<{ description: string; quantity: number; total: number }>).map(item => `${item.description} — ${item.quantity} × ${currency.format(Number(item.total) / Number(item.quantity))} = ${currency.format(Number(item.total))}`).join('\n');
    const message = [
      `Hello ${invoice.customer_name},`,
      '',
      `Your invoice ${invoice.invoice_number} from ${context.workspace.name} is ready.`,
      '',
      lineSummary,
      '',
      `Subtotal: ${currency.format(Number(invoice.subtotal))}`,
      `Tax (${Number(invoice.tax_rate)}%): ${currency.format(Number(invoice.tax_amount))}`,
      `Total due: ${currency.format(Number(invoice.total))}`,
      invoice.due_date ? `Due date: ${invoice.due_date}` : '',
      invoice.notes ? `Note: ${invoice.notes}` : '',
      '',
      `Review your invoice and pay securely online: ${invoiceUrl}`,
      '',
      `Thank you,`, context.workspace.name
    ].filter(Boolean).join('\n');
    const raw = makeGmailRawMessage({ to: invoice.customer_email, subject: `Invoice ${invoice.invoice_number} from ${context.workspace.name}`, text: message });
    const result = await gmail.users.messages.send({ userId: 'me', requestBody: { raw } });
    const now = new Date().toISOString();
    const { error: updateError } = await admin.from('invoices').update({ status: 'sent', sent_at: now, updated_at: now }).eq('id', invoice.id).eq('workspace_id', context.workspace.id);
    if (updateError) throw new Error('The email was sent, but LeadFlow could not update the invoice status. Refresh the invoice list.');
    if (invoice.lead_id) await admin.from('leads').update({ status: 'quote_sent', updated_at: now }).eq('id', invoice.lead_id).eq('workspace_id', context.workspace.id);
    await admin.from('activity_logs').insert({ workspace_id: context.workspace.id, lead_id: invoice.lead_id, actor_id: context.user.id, action: 'invoice.sent', details: { invoice_id: invoice.id, invoice_number: invoice.invoice_number, recipient: invoice.customer_email, gmail_message_id: result.data.id } });
    return NextResponse.json({ ok: true, invoiceUrl, messageId: result.data.id });
  } catch (error) {
    const detail = error instanceof Error ? error.message : 'Invoice email could not be sent.';
    return NextResponse.json({ error: detail }, { status: 400 });
  }
}
