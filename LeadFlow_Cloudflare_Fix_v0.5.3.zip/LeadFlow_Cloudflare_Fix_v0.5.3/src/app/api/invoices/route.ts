import { NextResponse } from 'next/server';
import { getWorkspaceContext } from '@/lib/auth';
import { createSupabaseAdminClient } from '@/lib/supabase/admin';
import { calculateInvoice } from '@/lib/invoices.mjs';

export const dynamic = 'force-dynamic';

export async function GET() {
  const context = await getWorkspaceContext();
  if (!context?.user || !context.workspace) return NextResponse.json({ error: 'Sign in first.' }, { status: 401 });
  const { data, error } = await context.supabase.from('invoices')
    .select('id,invoice_number,public_token,lead_id,customer_name,customer_email,currency,items,subtotal,tax_rate,tax_amount,total,notes,due_date,status,sent_at,paid_at,created_at')
    .eq('workspace_id', context.workspace.id).order('created_at', { ascending: false }).limit(100);
  if (error) return NextResponse.json({ error: 'Could not load invoices. Run migration 0002_invoices.sql.' }, { status: 500 });
  return NextResponse.json({ invoices: data ?? [] });
}

export async function POST(request: Request) {
  try {
    const context = await getWorkspaceContext();
    if (!context?.user || !context.workspace) return NextResponse.json({ error: 'Sign in first.' }, { status: 401 });
    const body = await request.json();
    const leadId = body.lead_id ? String(body.lead_id) : null;
    let customerName = String(body.customer_name ?? '').trim();
    let customerEmail = String(body.customer_email ?? '').trim().toLowerCase();

    if (leadId) {
      const { data: lead } = await context.supabase.from('leads')
        .select('id,customer_name,email').eq('id', leadId).eq('workspace_id', context.workspace.id).maybeSingle();
      if (!lead) return NextResponse.json({ error: 'Selected customer was not found in this workspace.' }, { status: 404 });
      customerName ||= lead.customer_name;
      customerEmail ||= lead.email ?? '';
    }
    if (customerName.length < 2 || customerName.length > 120) return NextResponse.json({ error: 'Enter a customer name.' }, { status: 400 });
    if (!/^\S+@\S+\.\S+$/.test(customerEmail) || customerEmail.length > 254) return NextResponse.json({ error: 'A valid customer email is required to send an invoice.' }, { status: 400 });

    const totals = calculateInvoice(body.items, body.tax_rate ?? 0);
    if (totals.total <= 0) return NextResponse.json({ error: 'Invoice total must be greater than zero.' }, { status: 400 });
    const notes = String(body.notes ?? '').trim();
    if (notes.length > 1500) return NextResponse.json({ error: 'Notes are too long.' }, { status: 400 });
    let dueDate: string | null = null;
    if (body.due_date) {
      dueDate = String(body.due_date);
      if (!/^\d{4}-\d{2}-\d{2}$/.test(dueDate) || Number.isNaN(Date.parse(`${dueDate}T00:00:00Z`))) {
        return NextResponse.json({ error: 'Enter a valid due date.' }, { status: 400 });
      }
    }

    const admin = createSupabaseAdminClient();
    const invoiceNumber = `LF-${new Date().getUTCFullYear()}-${crypto.randomUUID().slice(0, 8).toUpperCase()}`;
    const { data: invoice, error } = await admin.from('invoices').insert({
      workspace_id: context.workspace.id, lead_id: leadId, invoice_number: invoiceNumber,
      customer_name: customerName, customer_email: customerEmail, currency: 'usd',
      items: totals.items, subtotal: totals.subtotal, tax_rate: totals.taxRate,
      tax_amount: totals.taxAmount, total: totals.total, notes: notes || null,
      due_date: dueDate, status: 'draft', created_by: context.user.id
    }).select('id,invoice_number,public_token,lead_id,customer_name,customer_email,currency,items,subtotal,tax_rate,tax_amount,total,notes,due_date,status,sent_at,paid_at,created_at').single();
    if (error || !invoice) throw new Error('Invoice could not be saved. Check that migration 0002_invoices.sql has been run.');
    await admin.from('activity_logs').insert({ workspace_id: context.workspace.id, lead_id: leadId, actor_id: context.user.id, action: 'invoice.created', details: { invoice_id: invoice.id, invoice_number: invoice.invoice_number, total: invoice.total } });
    return NextResponse.json({ invoice }, { status: 201 });
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : 'Invoice could not be created.' }, { status: 400 });
  }
}
