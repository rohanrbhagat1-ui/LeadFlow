import { NextResponse } from 'next/server';
import { getWorkspaceContext } from '@/lib/auth';
import { deleteStripeConnection } from '@/lib/stripe-connect';

export async function POST() {
  try {
    const context = await getWorkspaceContext();
    if (!context?.user || !context.workspace) return NextResponse.json({ error: 'Sign in first.' }, { status: 401 });
    if (!['owner', 'admin'].includes(context.role ?? '')) return NextResponse.json({ error: 'Only the workspace owner or admin can disconnect Stripe.' }, { status: 403 });
    await deleteStripeConnection(context.workspace.id);
    return NextResponse.json({ ok: true });
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : 'Stripe could not be disconnected.' }, { status: 400 });
  }
}
