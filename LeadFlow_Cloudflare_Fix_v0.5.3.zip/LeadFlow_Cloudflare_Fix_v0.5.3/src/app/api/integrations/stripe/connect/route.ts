import { randomBytes } from 'node:crypto';
import { NextResponse } from 'next/server';
import { getWorkspaceContext } from '@/lib/auth';
import { getStripeConnectSetupStatus } from '@/lib/stripe-connect';

export async function GET(request: Request) {
  const context = await getWorkspaceContext();
  if (!context?.user || !context.workspace) return NextResponse.redirect(new URL('/login', request.url));
  if (!['owner', 'admin'].includes(context.role ?? '')) {
    return NextResponse.redirect(new URL('/dashboard?integrationError=Only+the+workspace+owner+or+admin+can+connect+payments', request.url));
  }
  const setup = getStripeConnectSetupStatus();
  if (!setup.ready) {
    return NextResponse.redirect(new URL(`/dashboard?integrationError=${encodeURIComponent(`Stripe setup is incomplete: ${setup.missing.join(', ')}`)}`, request.url));
  }
  const state = randomBytes(32).toString('hex');
  const redirectUri = process.env.STRIPE_CONNECT_REDIRECT_URI!;
  const authorize = new URL('https://connect.stripe.com/oauth/authorize');
  authorize.searchParams.set('response_type', 'code');
  authorize.searchParams.set('client_id', process.env.STRIPE_CONNECT_CLIENT_ID!);
  authorize.searchParams.set('scope', 'read_write');
  authorize.searchParams.set('state', state);
  authorize.searchParams.set('redirect_uri', redirectUri);
  const response = NextResponse.redirect(authorize);
  response.cookies.set('leadflow_stripe_state', state, {
    httpOnly: true, secure: true, sameSite: 'lax',
    path: '/api/integrations/stripe/callback', maxAge: 600
  });
  return response;
}
