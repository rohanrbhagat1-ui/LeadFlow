import { timingSafeEqual } from 'node:crypto';
import { cookies } from 'next/headers';
import { NextResponse } from 'next/server';
import { getWorkspaceContext } from '@/lib/auth';
import { getStripeConnectSetupStatus, saveStripeConnection } from '@/lib/stripe-connect';

const STATE_COOKIE = 'leadflow_stripe_state';
const COOKIE_OPTIONS = { httpOnly: true, secure: true, sameSite: 'lax' as const, path: '/api/integrations/stripe/callback', maxAge: 0 };
function finish(path: string, origin: string) {
  const response = NextResponse.redirect(new URL(path, origin));
  response.cookies.set(STATE_COOKIE, '', COOKIE_OPTIONS);
  return response;
}

export async function GET(request: Request) {
  const url = new URL(request.url);
  const code = url.searchParams.get('code') ?? '';
  const state = url.searchParams.get('state') ?? '';
  const denied = url.searchParams.get('error');
  const cookieStore = await cookies();
  const savedState = cookieStore.get(STATE_COOKIE)?.value ?? '';
  const a = Buffer.from(state, 'utf8');
  const b = Buffer.from(savedState, 'utf8');
  const validState = a.length > 0 && a.length === b.length && timingSafeEqual(a, b);
  if (denied) return finish('/dashboard?integrationError=Stripe+authorization+was+cancelled', url.origin);
  if (!code || !validState) return finish('/dashboard?integrationError=Stripe+connection+state+did+not+match', url.origin);

  const context = await getWorkspaceContext();
  if (!context?.user || !context.workspace) return finish('/login?message=Sign+in+before+connecting+Stripe', url.origin);
  if (!['owner', 'admin'].includes(context.role ?? '')) return finish('/dashboard?integrationError=Only+the+workspace+owner+or+admin+can+connect+Stripe', url.origin);
  const setup = getStripeConnectSetupStatus();
  if (!setup.ready) return finish(`/dashboard?integrationError=${encodeURIComponent(`Stripe setup is incomplete: ${setup.missing.join(', ')}`)}`, url.origin);

  try {
    const body = new URLSearchParams({ code, grant_type: 'authorization_code' });
    const basicAuth = Buffer.from(`${process.env.STRIPE_SECRET_KEY}:`, 'utf8').toString('base64');
    const response = await fetch('https://connect.stripe.com/oauth/token', {
      method: 'POST', headers: { 'content-type': 'application/x-www-form-urlencoded', authorization: `Basic ${basicAuth}` }, body,
      signal: AbortSignal.timeout(12000), cache: 'no-store', redirect: 'error'
    });
    const result = await response.json() as { stripe_user_id?: string; livemode?: boolean; error?: string; error_description?: string };
    if (!response.ok || !result.stripe_user_id) throw new Error(result.error_description || result.error || 'Stripe did not return a connected account.');
    await saveStripeConnection(context.workspace.id, result.stripe_user_id, Boolean(result.livemode));
    return finish('/dashboard?connected=stripe', url.origin);
  } catch {
    return finish('/dashboard?integrationError=Stripe+could+not+complete+the+connection.+Check+the+platform+OAuth+settings+and+try+again', url.origin);
  }
}
