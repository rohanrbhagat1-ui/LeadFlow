import { NextResponse } from 'next/server';
import { createSupabaseAdminClient } from '@/lib/supabase/admin';
import { verifyStripeSignature } from '@/lib/payments.mjs';
import { getConnectedStripeAccount } from '@/lib/stripe-connect';

export const dynamic = 'force-dynamic';

export async function POST(request: Request) {
  const secret = process.env.STRIPE_WEBHOOK_SECRET;
  if (!secret) return NextResponse.json({ error: 'Connect webhook secret is not configured.' }, { status: 503 });
  const signature = request.headers.get('stripe-signature') ?? '';
  const rawBody = await request.text();
  if (!verifyStripeSignature(rawBody, signature, secret)) return NextResponse.json({ error: 'Invalid webhook signature.' }, { status: 400 });

  try {
    const event = JSON.parse(rawBody) as { id: string; type: string; account?: string; livemode?: boolean; data?: { object?: Record<string, any> } };
    if (event.type !== 'checkout.session.completed' && event.type !== 'checkout.session.async_payment_succeeded') {
      return NextResponse.json({ received: true, ignored: true });
    }
    const session = event.data?.object ?? {};
    if (session.payment_status !== 'paid' && event.type !== 'checkout.session.async_payment_succeeded') {
      return NextResponse.json({ received: true, ignored: true });
    }
    const invoiceId = String(session.metadata?.invoice_id ?? '');
    const workspaceId = String(session.metadata?.workspace_id ?? '');
    if (!invoiceId || !workspaceId || !event.account) return NextResponse.json({ error: 'Connected-account checkout metadata is incomplete.' }, { status: 400 });

    const admin = createSupabaseAdminClient();
    const { data: existingInvoice, error: lookupError } = await admin.from('invoices')
      .select('id,lead_id,invoice_number,total,status,currency')
      .eq('id', invoiceId).eq('workspace_id', workspaceId).maybeSingle();
    if (lookupError || !existingInvoice) throw new Error('The invoice referenced by this payment was not found.');

    const connected = await getConnectedStripeAccount(workspaceId);
    if (!connected || connected.accountId !== event.account) {
      return NextResponse.json({ error: 'The payment event account does not match the connected business account.' }, { status: 400 });
    }
    if (Boolean(connected.livemode) !== Boolean(event.livemode)) {
      return NextResponse.json({ error: 'The payment event mode does not match the connected account mode.' }, { status: 400 });
    }
    if (existingInvoice.status === 'paid') return NextResponse.json({ received: true, duplicate: true });
    if (existingInvoice.status !== 'sent') return NextResponse.json({ error: 'Only issued invoices can be marked paid.' }, { status: 409 });

    const expectedCents = Math.round(Number(existingInvoice.total) * 100);
    if (Number(session.amount_total) !== expectedCents || String(session.currency).toLowerCase() !== 'usd' || existingInvoice.currency !== 'usd') {
      throw new Error('The payment amount or currency does not match the invoice.');
    }
    const now = new Date().toISOString();
    const { data: invoice, error } = await admin.from('invoices').update({
      status: 'paid', paid_at: now, payment_provider: 'stripe',
      stripe_checkout_session_id: String(session.id ?? ''),
      stripe_payment_intent_id: typeof session.payment_intent === 'string' ? session.payment_intent : null,
      updated_at: now
    }).eq('id', invoiceId).eq('workspace_id', workspaceId).eq('status', 'sent')
      .select('id,lead_id,invoice_number,total').maybeSingle();
    if (error) throw new Error('Invoice payment could not be recorded.');
    if (invoice) {
      if (invoice.lead_id) await admin.from('leads').update({ status: 'won', updated_at: now }).eq('id', invoice.lead_id).eq('workspace_id', workspaceId);
      await admin.from('activity_logs').insert({ workspace_id: workspaceId, lead_id: invoice.lead_id, action: 'invoice.paid', details: { invoice_id: invoice.id, invoice_number: invoice.invoice_number, total: invoice.total, stripe_event_id: event.id } });
    }
    return NextResponse.json({ received: true });
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : 'Webhook processing failed.' }, { status: 500 });
  }
}
