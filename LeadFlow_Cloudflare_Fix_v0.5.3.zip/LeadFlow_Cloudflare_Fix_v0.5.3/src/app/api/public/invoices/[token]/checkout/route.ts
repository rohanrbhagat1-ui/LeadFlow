import { NextResponse } from 'next/server';
import { createSupabaseAdminClient } from '@/lib/supabase/admin';
import { createStripeCheckoutParams } from '@/lib/payments.mjs';
import { getConnectedStripeAccount, getStripeConnectSetupStatus } from '@/lib/stripe-connect';

export async function POST(_request: Request, { params }: { params: Promise<{ token: string }> }) {
  try {
    const setup = getStripeConnectSetupStatus();
    if (!setup.ready) return NextResponse.json({ error: 'Online payments are not configured.' }, { status: 503 });
    const { token } = await params;
    const admin = createSupabaseAdminClient();
    const { data: invoice, error } = await admin.from('invoices')
      .select('id,workspace_id,invoice_number,public_token,customer_name,customer_email,currency,items,subtotal,tax_rate,tax_amount,total,status,stripe_checkout_session_id')
      .eq('public_token', token).maybeSingle();
    if (error || !invoice) return NextResponse.json({ error: 'Invoice not found.' }, { status: 404 });
    if (invoice.status === 'paid') return NextResponse.json({ error: 'This invoice has already been paid.' }, { status: 409 });
    if (invoice.status === 'void') return NextResponse.json({ error: 'This invoice is no longer payable.' }, { status: 409 });
    if (invoice.status !== 'sent') return NextResponse.json({ error: 'This invoice has not been issued by the business yet.' }, { status: 409 });

    const connected = await getConnectedStripeAccount(invoice.workspace_id);
    if (!connected) return NextResponse.json({ error: 'This business has not connected its own Stripe account.' }, { status: 503 });
    const platformKey = process.env.STRIPE_SECRET_KEY!;
    const isTestKey = platformKey.startsWith('sk_test_');
    if (connected.livemode === isTestKey) return NextResponse.json({ error: 'The connected Stripe account mode does not match the platform test/live mode.' }, { status: 409 });
    const siteUrl = (process.env.NEXT_PUBLIC_SITE_URL ?? '').replace(/\/$/, '');
    if (!siteUrl.startsWith('https://')) return NextResponse.json({ error: 'The public invoice URL is not configured.' }, { status: 503 });
    const stripeHeaders = { authorization: `Bearer ${platformKey}`, 'Stripe-Account': connected.accountId };

    if (invoice.stripe_checkout_session_id) {
      const existingResponse = await fetch(`https://api.stripe.com/v1/checkout/sessions/${encodeURIComponent(invoice.stripe_checkout_session_id)}`, {
        headers: stripeHeaders, cache: 'no-store', redirect: 'error', signal: AbortSignal.timeout(8000)
      });
      if (existingResponse.ok) {
        const existing = await existingResponse.json() as { status?: string; url?: string };
        if (existing.status === 'open' && existing.url) return NextResponse.redirect(existing.url, 303);
      }
    }

    const form = createStripeCheckoutParams(invoice, siteUrl);
    const response = await fetch('https://api.stripe.com/v1/checkout/sessions', {
      method: 'POST', headers: { ...stripeHeaders, 'content-type': 'application/x-www-form-urlencoded' },
      body: form.toString(), signal: AbortSignal.timeout(12000), cache: 'no-store', redirect: 'error'
    });
    const session = await response.json() as { id?: string; url?: string; error?: { message?: string } };
    if (!response.ok || !session.url || !session.id) throw new Error(session.error?.message || 'The connected business account could not create checkout.');
    await admin.from('invoices').update({ payment_provider: 'stripe', stripe_checkout_session_id: session.id, updated_at: new Date().toISOString() }).eq('id', invoice.id);
    return NextResponse.redirect(session.url, 303);
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : 'Payment checkout could not be opened.' }, { status: 400 });
  }
}
