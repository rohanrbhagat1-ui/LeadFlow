import { notFound } from 'next/navigation';
import { createSupabaseAdminClient } from '@/lib/supabase/admin';
import { getConnectedStripeAccount, getStripeConnectSetupStatus } from '@/lib/stripe-connect';
import PrintInvoiceButton from '@/components/print-invoice-button';

export const dynamic = 'force-dynamic';
export const metadata = { title: 'Customer invoice | LeadFlow', robots: { index: false, follow: false } };

const money = (value: number) => new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(value);

export default async function PublicInvoicePage({ params, searchParams }: { params: Promise<{ token: string }>; searchParams: Promise<{ payment?: string }> }) {
  const { token } = await params;
  const query = await searchParams;
  let invoice: any = null;
  let businessName = 'Your service provider';
  try {
    const admin = createSupabaseAdminClient();
    const { data } = await admin.from('invoices').select('id,workspace_id,invoice_number,public_token,customer_name,customer_email,items,subtotal,tax_rate,tax_amount,total,notes,due_date,status,sent_at,paid_at')
      .eq('public_token', token).maybeSingle();
    invoice = data;
    if (invoice) {
      const { data: workspace } = await admin.from('workspaces').select('name').eq('id', invoice.workspace_id).maybeSingle();
      businessName = workspace?.name ?? businessName;
    }
  } catch { notFound(); }
  if (!invoice) notFound();
  const items = invoice.items as Array<{ description: string; quantity: number; unit_price: number; total: number }>;
  let stripeReady = false;
  try {
    stripeReady = getStripeConnectSetupStatus().ready && Boolean(await getConnectedStripeAccount(invoice.workspace_id));
  } catch {
    stripeReady = false;
  }
  return <main className="public-invoice-shell">
    <article className="public-invoice-card">
      <div className="invoice-public-brand"><span className="brandmark">↗</span><div><strong>{businessName}</strong><small>Invoice issued through LeadFlow</small></div></div>
      <div className="invoice-public-heading"><div><p className="eyebrow">Invoice</p><h1>{invoice.invoice_number}</h1><p className="public-muted">For {invoice.customer_name}</p></div><div className="invoice-public-actions"><span className={`invoice-status status-${invoice.status}`}>{invoice.status}</span><PrintInvoiceButton /></div></div>
      {query.payment === 'success' && <div className="alert success">Payment submitted. Your payment provider is confirming the transaction; this page will update once confirmation arrives.</div>}
      {query.payment === 'cancelled' && <div className="alert">Checkout was cancelled. You can return here and try again.</div>}
      <div className="invoice-lines"><div className="invoice-line invoice-line-head"><span>Description</span><span>Amount</span></div>
        {items.map((item, index) => <div className="invoice-line" key={index}><span>{item.description}<small>{item.quantity} × {money(Number(item.unit_price))}</small></span><strong>{money(Number(item.total))}</strong></div>)}
      </div>
      <div className="invoice-totals"><div><span>Subtotal</span><strong>{money(Number(invoice.subtotal))}</strong></div><div><span>Tax ({Number(invoice.tax_rate)}%)</span><strong>{money(Number(invoice.tax_amount))}</strong></div><div className="invoice-grand-total"><span>{invoice.status === 'paid' ? 'Total paid' : 'Total due'}</span><strong>{money(Number(invoice.total))}</strong></div></div>
      {invoice.due_date && <p className="public-muted">Due date: {invoice.due_date}</p>}
      {invoice.notes && <div className="invoice-note"><strong>Note from {businessName}</strong><p>{invoice.notes}</p></div>}
      {invoice.status === 'paid' ? <div className="invoice-paid">✓ Payment received on {new Date(invoice.paid_at).toLocaleDateString('en-US')}</div> : invoice.status === 'void' ? <div className="alert error">This invoice has been voided. Contact the business with questions.</div> : invoice.status !== 'sent' ? <div className="alert">This invoice is still a draft and has not yet been issued by the business.</div> : stripeReady ? <form action={`/api/public/invoices/${token}/checkout`} method="post"><button className="button primary pay-button" type="submit">Pay securely online · {money(Number(invoice.total))}</button><p className="public-muted center">Secure checkout is provided by Stripe. LeadFlow never receives or stores card details.</p></form> : <div className="alert">Online payment is not currently enabled. Please contact {businessName} for payment instructions.</div>}
      <footer className="invoice-public-footer">Questions about this invoice? Contact {businessName}.<br/>Powered by LeadFlow.</footer>
    </article>
  </main>;
}
