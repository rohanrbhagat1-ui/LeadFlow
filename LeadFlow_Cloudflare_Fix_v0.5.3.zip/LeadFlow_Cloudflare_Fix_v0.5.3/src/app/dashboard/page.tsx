import { redirect } from 'next/navigation';
import DashboardClient from '@/components/dashboard-client';
import { requireWorkspace } from '@/lib/workspace';
import { createSupabaseAdminClient } from '@/lib/supabase/admin';
import { getGoogleSetupStatus } from '@/lib/google';
import { getStripeConnectSetupStatus } from '@/lib/stripe-connect';

export const dynamic = 'force-dynamic';

export default async function DashboardPage({ searchParams }: { searchParams: Promise<{ integrationError?: string; connected?: string }> }) {
  const context = await requireWorkspace();
  if (!context) {
    redirect('/login');
    return null;
  }
  const { supabase, user, workspace, role } = context;
  const [{ data: leads, error }, { data: invoices, error: invoiceError }] = await Promise.all([
    supabase.from('leads').select('id,customer_name,email,phone,offering,location_context,source,status,estimated_value,follow_up_at,notes,contact_permission,created_at').eq('workspace_id', workspace.id).order('created_at', { ascending: false }).limit(100),
    supabase.from('invoices').select('id,invoice_number,public_token,lead_id,customer_name,customer_email,currency,items,subtotal,tax_rate,tax_amount,total,notes,due_date,status,sent_at,paid_at,created_at').eq('workspace_id', workspace.id).order('created_at', { ascending: false }).limit(100)
  ]);
  if (error) throw new Error('Could not load workspace leads. Check the database migration and row-level security policies.');
  if (invoiceError && !invoiceError.message.toLowerCase().includes('does not exist')) throw new Error('Could not load invoices. Check migration 0002_invoices.sql.');

  let integrations: { provider: string; status: string; account_email: string | null }[] = [];
  try {
    const admin = createSupabaseAdminClient();
    const { data } = await admin.from('integrations').select('provider,status,account_email').eq('workspace_id', workspace.id);
    integrations = data ?? [];
  } catch { /* Show clear connection setup status in the client. */ }
  const googleSetup = getGoogleSetupStatus();
  const stripeSetup = getStripeConnectSetupStatus();
  const stripeConnected = integrations.some((item) => item.provider === 'stripe' && item.status === 'connected');
  const search = await searchParams;
  return <DashboardClient workspace={workspace} userEmail={user.email ?? ''} role={role}
    initialLeads={leads ?? []} initialInvoices={invoices ?? []} initialIntegrations={integrations}
    googleSetup={googleSetup} stripeSetup={{ ready: stripeSetup.ready, missing: stripeSetup.missing, connected: stripeConnected }}
    siteUrl={process.env.NEXT_PUBLIC_SITE_URL ?? ''} initialMessage={search.integrationError ?? (search.connected === 'google' ? 'Google is connected.' : search.connected === 'stripe' ? 'This business Stripe account is connected.' : '')} />;
}
