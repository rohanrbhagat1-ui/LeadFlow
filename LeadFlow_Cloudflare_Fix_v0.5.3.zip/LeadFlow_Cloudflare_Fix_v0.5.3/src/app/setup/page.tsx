export const dynamic = 'force-dynamic';
export default function SetupPage() {
  return <main className="auth-shell"><section className="auth-card"><div className="brand-lockup"><span className="brandmark">↗</span><div><b>LeadFlow</b><small>Business operations, connected.</small></div></div><p className="eyebrow">Workspace setup</p><h1>LeadFlow needs its database connection.</h1><p className="muted">The public Supabase URL and publishable key are not available to this deployment. Add NEXT_PUBLIC_SUPABASE_URL and NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY to Cloudflare Build variables and Production runtime variables, then deploy again.</p></section></main>;
}
