# GitHub update path

This development repository already has a GitHub Actions workflow named **Expand LeadFlow source package** at `.github/workflows/expand-leadflow.yml`.

To update the app, upload the release ZIP named `LeadFlow_Cloudflare_Fix_v0.5.3.zip` to the repository root, then run that workflow on `main`. It expands the package folder into the repository root, commits the app files, and triggers Cloudflare Workers Builds.

Do not upload `.env.local`, API keys, OAuth client secrets, Stripe secret keys, Supabase secret keys, encryption keys, or customer data.
