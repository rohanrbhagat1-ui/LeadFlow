# Cloudflare Workers Builds — LeadFlow

- Root directory: `/` (the folder with `package.json`)
- Build command: `npx @opennextjs/cloudflare build`
- Deploy command: `npx @opennextjs/cloudflare deploy`

Do not deploy this Next.js application as a static site. It needs the OpenNext Cloudflare adapter and server-side Worker runtime. `NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY`, and `NEXT_PUBLIC_SITE_URL` must be present as build variables. The same values plus the server-only secrets and provider credentials must be present in the Production runtime environment.

See `CLOUDFLARE_SETUP_V07.md` for the full Google and per-business Stripe Connect setup.
