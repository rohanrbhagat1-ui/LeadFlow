# LeadFlow v0.7.0 — Cloudflare, Google and Stripe Connect setup

This release adds itemized invoices, customer-facing invoice pages, Gmail delivery, Google Calendar scheduling, and Stripe Connect for per-business payments. It is an early test build, not a certified production payment platform.

## 0. Important account ownership

A parent/guardian or legitimate adult business owner must manage the Google Cloud and Stripe platform accounts, business verification, payment agreements, billing, and any payout or tax requirements. Each customer business must authorize its own payment account. Do not bypass any provider age, identity, or business requirements. Keep Stripe in test mode until an adult/business owner has reviewed the setup and the product is ready for live payments.

## 1. Update the application code

The existing GitHub Actions workflow in this repository expects a ZIP named exactly `LeadFlow_Cloudflare_Fix_v0.5.3.zip`. The new package is built to work with that workflow.

1. Back up the repository first.
2. Upload the new `LeadFlow_Cloudflare_Fix_v0.5.3.zip` to the repository root (not inside a subfolder).
3. Open GitHub → Actions → **Expand LeadFlow source package** → **Run workflow** → choose `main`.
4. Wait for the workflow to finish successfully. It expands the app files into the repository root and commits them.
5. Cloudflare Workers Builds should start a new build from the commit.

Do not put API keys, OAuth secrets, database secrets, or real customer information into GitHub. The repository is currently public in the development setup; change it to private with adult/guardian help before using this for business data.

## 2. Supabase database migration

The project already has migration `0001_initial.sql`. Do not rerun that initial migration unless you are intentionally rebuilding the database.

Run the updated `supabase/migrations/0002_invoices.sql` in Supabase SQL Editor. It:

- Creates the workspace-scoped `invoices` table and row-level security policy.
- Updates the allowed integration providers to include `stripe`.
- Is safe to run again; the invoices table is created only if absent and the provider constraint is replaced idempotently.

If you previously ran an earlier v0.6 copy of migration 0002, run this updated file again so the `stripe` provider is allowed.

## 3. Generate two private application secrets

In Supabase SQL Editor, run:

```sql
select
  encode(gen_random_bytes(32), 'hex') as integration_encryption_key,
  encode(gen_random_bytes(32), 'hex') as intake_rate_limit_secret;
```

Copy the two returned values directly into their Cloudflare Secret fields. Each is 64 hexadecimal characters. Never paste them into ChatGPT or GitHub. Losing the encryption key makes stored Google/Stripe connection data unreadable, so the account owner should store a protected backup.

## 4. Cloudflare Build variables

In Cloudflare → Workers & Pages → your LeadFlow Worker → Settings → Builds (Build variables and secrets), configure these **Text / Variable** entries:

| Name | Value |
|---|---|
| `NEXT_PUBLIC_SUPABASE_URL` | Your Supabase Project URL |
| `NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY` | Your Supabase publishable key |
| `NEXT_PUBLIC_SITE_URL` | `https://YOUR-WORKER.workers.dev` |

Use the exact public Worker address displayed under Domains. The current development address in the prior setup was `https://leadflow222.rohanbhagat1.workers.dev`.

## 5. Cloudflare Production Runtime variables and secrets

In Worker → Settings → Bindings → Runtime variables and secrets, add:

| Name | Cloudflare type | Purpose |
|---|---|---|
| `NEXT_PUBLIC_SUPABASE_URL` | Variable | Supabase Project URL |
| `NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY` | Variable | Supabase publishable key |
| `NEXT_PUBLIC_SITE_URL` | Variable | Exact HTTPS Worker URL |
| `GOOGLE_CLIENT_ID` | Variable | Google OAuth web client ID |
| `GOOGLE_REDIRECT_URI` | Variable | Exact Google callback below |
| `STRIPE_CONNECT_CLIENT_ID` | Variable | Stripe Connect test-mode client ID (`ca_...`) |
| `STRIPE_CONNECT_REDIRECT_URI` | Variable | Exact Stripe callback below |
| `SUPABASE_SECRET_KEY` | Secret | Server-side Supabase database key |
| `INTEGRATION_ENCRYPTION_KEY` | Secret | 64-character secret generated above |
| `INTAKE_RATE_LIMIT_SECRET` | Secret | 64-character secret generated above |
| `GOOGLE_CLIENT_SECRET` | Secret | Google OAuth client secret |
| `STRIPE_SECRET_KEY` | Secret | Stripe platform test-mode secret key (`sk_test_...`) |
| `STRIPE_WEBHOOK_SECRET` | Secret | Stripe Connect webhook signing secret (`whsec_...`) |

If your Supabase project still uses a legacy service-role key, the application accepts `SUPABASE_SERVICE_ROLE_KEY` as a server-only fallback, but prefer the current `SUPABASE_SECRET_KEY`. Never prefix this private key with `NEXT_PUBLIC_`.

## 6. Connect Gmail and Google Calendar

An adult/guardian or business account owner should manage the Google Cloud project and OAuth configuration.

1. Create or choose a Google Cloud project.
2. Enable Gmail API and Google Calendar API.
3. Configure Google Auth Platform / OAuth consent screen. Use Testing during development and add the adult-managed account used for testing as a test user.
4. Create an OAuth Client ID of type **Web application**.
5. Add this exact Authorized redirect URI:
   `https://YOUR-WORKER.workers.dev/api/integrations/google/callback`
6. Put the Google Client ID and Client Secret into Cloudflare runtime settings above.
7. Set `GOOGLE_REDIRECT_URI` to exactly the same callback URL.
8. Redeploy the Worker, sign in to LeadFlow, open Integrations, and choose **Connect Google account**.

The app requests `gmail.send` and `calendar.events`. Google may require app verification before external users can authorize these sensitive scopes. OAuth Testing mode can also cause non-basic-scope refresh tokens to expire after seven days. Testing mode is for limited testing, not a general customer rollout.

## 7. Configure Stripe Connect for each business

LeadFlow uses Stripe Connect Standard OAuth. Each business authorizes its **own** Stripe account. Payment Checkout Sessions are created as direct charges on that connected account using the platform's secret key with the `Stripe-Account` header. This means the business account receives the payment; LeadFlow does not collect customer card information and this version does not take an application fee.

A parent/guardian or the actual adult business owner must manage the LeadFlow Stripe platform account and Connect setup. A business owner must authorize their own Stripe merchant account. Stripe may require platform review, account verification, and agreements before live use.

1. Open the adult-managed Stripe platform dashboard and enable Stripe Connect / OAuth for Standard accounts.
2. Start in **Test mode** and copy the test-mode Connect Client ID (`ca_...`). Put it in `STRIPE_CONNECT_CLIENT_ID`.
3. Add this exact OAuth redirect URI in the Stripe Connect OAuth settings:
   `https://YOUR-WORKER.workers.dev/api/integrations/stripe/callback`
4. Put the matching test-mode platform secret key (`sk_test_...`) in `STRIPE_SECRET_KEY`.
5. In Stripe Workbench / Webhooks, create a **Connect** webhook endpoint for connected-account events at:
   `https://YOUR-WORKER.workers.dev/api/webhooks/stripe`
6. Subscribe at minimum to:
   - `checkout.session.completed`
   - `checkout.session.async_payment_succeeded`
7. Copy that endpoint's signing secret into `STRIPE_WEBHOOK_SECRET`.
8. Deploy the Worker again.
9. In LeadFlow → Integrations → Online payments, choose **Connect this business's Stripe account** and authorize the business's own test account.
10. Create a draft invoice, issue it from the Invoices tab (Gmail must also be connected), open the invoice page, and complete a Stripe test payment.

The platform `STRIPE_SECRET_KEY`, Connect Client ID, and connected account must all use the same test/live mode. The app rejects a mode mismatch. Do not switch to live mode or accept real payments until the adult/business owner has completed verification, reviewed Stripe's Connect responsibilities and agreements, and tested refunds/disputes and the full payment reconciliation process.

## 8. Build settings

For Cloudflare Workers Builds:

- Root directory: `/` (the folder containing `package.json`)
- Build command: `npx @opennextjs/cloudflare build`
- Deploy command: `npx @opennextjs/cloudflare deploy`

The repository's `package.json` keeps `build` as `next build --webpack` and defines `preview` / `deploy` scripts for local development workflows.

## 9. Features in v0.7.0

- Multi-business workspaces and cloud-backed lead/customer pipeline.
- Ten business presets for common small-business categories.
- Itemized invoice drafts with calculated line totals, tax, due date, and notes.
- Public invoice page with print / Save as PDF support.
- Send invoice from the workspace's connected Gmail account.
- Per-business Stripe Connect Standard authorization and Stripe-hosted Checkout.
- Connected-account webhook verification; invoice is marked paid only after a verified Stripe event with matching account, invoice, amount, and currency.
- Lead pipeline advances to quote-sent when an invoice is emailed and won when the invoice is verified paid.
- Google Calendar appointment creation.
- Make/Zapier webhook forwarding.
- Improved integration diagnostics listing missing configuration.

## 10. Not yet included / production checklist

Not included yet: built-in accounting reconciliation, automated tax determination, refunds/disputes UI, recurring billing, QuickBooks/Xero sync, file attachments, customer portal, SaaS subscription billing for LeadFlow, PDF generation on the server, team invitation emails, and advanced audit exports.

Before onboarding paying customers, complete a security review, privacy/retention terms, abuse controls, automated backups and restore testing, monitoring, verified email domain, Google OAuth verification as applicable, Stripe Connect platform approval and legal/accounting review, and payment/refund/dispute testing. Business owners remain responsible for setting lawful tax rates and invoice terms for their jurisdictions.
