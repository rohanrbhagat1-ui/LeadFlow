# LeadFlow Cloud v0.7.0

LeadFlow is a multi-tenant operations platform for small service businesses. The product is designed around the core workflow: capture an inquiry, manage the opportunity, send an estimate/invoice, collect payment through the business's own merchant account, and keep the customer record current.

## Core capabilities

- Next.js App Router application deployed to Cloudflare Workers through OpenNext.
- Supabase Auth and PostgreSQL with workspace-level row-level security.
- Configurable business workspaces for landscaping, cleaning, home repair, tutoring, auto detailing, pet care, professional services, photography, retail and other service businesses.
- Customer lead pipeline with activity history, follow-up dates and opportunity values.
- Itemized invoice drafts with server-calculated subtotal/tax/total and public invoice links.
- Gmail delivery and Google Calendar appointments after workspace OAuth connection.
- Stripe Connect Standard OAuth so each business connects its own Stripe account; hosted Checkout direct charges and signed connected-account webhook processing.
- Make/Zapier lead webhooks.

## Important payment architecture

LeadFlow does not collect or store card numbers. Every business must authorize its own Stripe account. The platform account uses Stripe Connect, while Checkout Sessions are created with a connected account header. Verified connected-account webhooks are required before an invoice is marked paid. There is no platform application fee in this version.

Stripe platform ownership, merchant account ownership, verification, account agreements, billing and any activation of live payments must be managed by an appropriate adult/legal business owner. Start in test mode.

## Setup

See `START_HERE.txt` and `CLOUDFLARE_SETUP_V07.md`. The Cloudflare deployment process uses the existing GitHub Actions workflow in your repository. Apply `supabase/migrations/0002_invoices.sql` after the initial `0001_initial.sql` migration.

## Cloudflare build

- Build: `npx @opennextjs/cloudflare build`
- Deploy: `npx @opennextjs/cloudflare deploy`
- Root: `/`

The package `build` script uses `next build --webpack` to avoid the earlier Next.js/Turbopack middleware output problem observed in the development deployment.

## Tests

Run `npm test` for pure-logic and migration checks. A full Next.js/Cloudflare production build must still be run in Cloudflare Workers Builds after provider variables and the updated database migration are set.

## Early-release limitations

This is an early release and not a certified production payment platform. It does not yet include refunds/dispute UI, accounting sync, automatic tax calculations, recurring billing, QuickBooks/Xero integration, team-invitation emails, server-generated PDFs, or LeadFlow subscription billing. Complete security, privacy, retention, operational, legal and accounting reviews before onboarding paying customers.
