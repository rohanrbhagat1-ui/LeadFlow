# LeadFlow v0.6 — Cloudflare and provider setup

## A. Supabase database
Run `supabase/migrations/0002_invoices.sql` in the existing Supabase project after migration 0001. This adds invoices with workspace-scoped row-level security. Invoice writes happen through authenticated server routes; Stripe is the only route that marks invoices paid.

## B. Runtime variables and secrets
In Cloudflare Workers & Pages → your LeadFlow Worker → Settings → Variables and Secrets → Production, configure:

| Name | Type | Purpose |
|---|---|---|
| `NEXT_PUBLIC_SUPABASE_URL` | Variable | Supabase project URL |
| `NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY` | Variable | Supabase publishable key |
| `NEXT_PUBLIC_SITE_URL` | Variable | `https://YOUR-WORKER.workers.dev` (add in build and runtime settings) |
| `SUPABASE_SECRET_KEY` | Secret | Server-side Supabase database access |
| `GOOGLE_CLIENT_ID` | Variable | Google OAuth Web client ID |
| `GOOGLE_CLIENT_SECRET` | Secret | Google OAuth client secret |
| `GOOGLE_REDIRECT_URI` | Variable | Exact callback URL below |
| `INTEGRATION_ENCRYPTION_KEY` | Secret | 64 hex chars (32 random bytes) |
| `INTAKE_RATE_LIMIT_SECRET` | Secret | 64 hex chars; used to hash rate-limit identifiers |
| `STRIPE_SECRET_KEY` | Secret | Start with Stripe test-mode `sk_test_...` |
| `STRIPE_WEBHOOK_SECRET` | Secret | Stripe webhook signing secret `whsec_...` |

`NEXT_PUBLIC_SITE_URL` should be added to both Build variables and Production runtime variables because it is a public URL used by Next.js.

Generate both random secrets without Terminal by running this query in Supabase SQL Editor (copy each returned value into its matching Cloudflare Secret):

```sql
select encode(gen_random_bytes(32), 'hex') as integration_encryption_key,
       encode(gen_random_bytes(32), 'hex') as intake_rate_limit_secret;
```

`GOOGLE_REDIRECT_URI` must be exactly:
`https://YOUR-WORKER.workers.dev/api/integrations/google/callback`

Replace YOUR-WORKER with the actual hostname shown by Cloudflare. The same exact URL must be registered in the Google OAuth client. Do not use a trailing slash.

## C. Google Gmail and Calendar
1. A parent/guardian or business account owner should manage the Google Cloud project and OAuth configuration.
2. Enable Gmail API and Google Calendar API.
3. Configure Google Auth Platform / OAuth consent screen. Use Testing while developing and add the account used for testing as a test user.
4. Create an OAuth Client ID of type Web application.
5. Add the exact callback above under Authorized redirect URIs.
6. Add the client ID, client secret, and redirect URI to Cloudflare Runtime variables/secrets.
7. Make a new Worker deployment, sign in to LeadFlow, open Integrations, and choose Connect Google account.

The app asks for `gmail.send` and `calendar.events`. Google may require additional verification before external users can authorize sensitive scopes. In OAuth Testing mode refresh tokens for scopes beyond basic identity can expire after 7 days; this is for testing, not general customer rollout.

## D. Stripe hosted checkout
1. A parent/guardian or the actual business owner must manage the Stripe account, verify the business and accept payment-provider agreements. Do not bypass age, identity, or business verification rules. Keep the integration in TEST mode until the adult/business owner has authorized live payments.
2. Start with Stripe TEST mode. Add the test secret key as `STRIPE_SECRET_KEY`.
3. In Stripe Workbench/Webhooks, create an endpoint pointing to:
   `https://YOUR-WORKER.workers.dev/api/webhooks/stripe`
4. Subscribe to `checkout.session.completed` and `checkout.session.async_payment_succeeded`.
5. Copy the endpoint signing secret into Cloudflare as `STRIPE_WEBHOOK_SECRET`.
6. Deploy again. Create a draft invoice, preview its public page, and use Stripe test payment details from the official Stripe testing documentation. Never use real card information in development.

LeadFlow creates hosted Stripe Checkout sessions on demand and sends the customer a public invoice page. Stripe handles the payment form and card data. The webhook verifies Stripe's signature before marking an invoice paid. Do not mark invoices paid manually.

## E. Build settings
Build command: `npx @opennextjs/cloudflare build`
Deploy command: `npx @opennextjs/cloudflare deploy`
Preview command: `npx @opennextjs/cloudflare preview`
Root directory: `/` (the folder containing package.json).

## F. Current feature scope
- Workspace-scoped customer leads and pipeline
- Itemized invoice drafts and public invoice pages
- Send invoice from connected Gmail account
- Stripe-hosted Checkout and signed payment webhooks
- Google Calendar appointment creation
- Make/Zapier webhook forwarding

Not yet implemented: recurring invoices, refunds, accounting reconciliation, QuickBooks/Xero sync, subscriptions/billing for LeadFlow itself, attachments/PDF generation, advanced team invitations, and automated tax calculations. A business owner remains responsible for confirming tax rates and invoice legal requirements.
