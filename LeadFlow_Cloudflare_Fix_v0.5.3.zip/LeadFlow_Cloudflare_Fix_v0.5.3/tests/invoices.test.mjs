import test from 'node:test';
import assert from 'node:assert/strict';
import { calculateInvoice, validatePaymentUrl } from '../src/lib/invoices.mjs';

test('calculates line totals, subtotal, tax and invoice total', () => {
  const result = calculateInvoice([
    { description: 'Lawn maintenance', quantity: 2, unit_price: 85 },
    { description: 'Mulch delivery', quantity: 1, unit_price: 40 }
  ], 6.5);
  assert.equal(result.subtotal, 210);
  assert.equal(result.taxAmount, 13.65);
  assert.equal(result.total, 223.65);
  assert.equal(result.items[0].total, 170);
});

test('rejects invalid invoice items and tax rates', () => {
  assert.throws(() => calculateInvoice([], 0), /between 1 and 20/);
  assert.throws(() => calculateInvoice([{ description: '', quantity: 1, unit_price: 10 }], 0), /needs a description/);
  assert.throws(() => calculateInvoice([{ description: 'Work', quantity: -1, unit_price: 10 }], 0), /invalid quantity/);
  assert.throws(() => calculateInvoice([{ description: 'Work', quantity: 1, unit_price: 10 }], 40), /between 0% and 25%/);
});

test('allows an empty payment link and accepts HTTPS links', () => {
  assert.deepEqual(validatePaymentUrl(''), { ok: true, url: null });
  assert.equal(validatePaymentUrl('https://buy.stripe.com/example').ok, true);
});

test('rejects insecure or credential-bearing payment links', () => {
  assert.equal(validatePaymentUrl('http://example.com/pay').ok, false);
  assert.equal(validatePaymentUrl('javascript:alert(1)').ok, false);
  assert.equal(validatePaymentUrl('https://user:pass@example.com/pay').ok, false);
});
