import test from 'node:test';
import assert from 'node:assert/strict';
import { createHmac } from 'node:crypto';
import { createStripeCheckoutParams, verifyStripeSignature } from '../src/lib/payments.mjs';

const invoice = {
  id: 'inv_123', workspace_id: 'ws_123', public_token: 'public-token-123',
  customer_email: 'customer@example.com', tax_rate: 6.5, tax_amount: 13.65,
  items: [
    { description: 'Lawn care', quantity: 2.5, unit_price: 80, total: 200 },
    { description: 'Mulch delivery', quantity: 1, unit_price: 10, total: 10 }
  ]
};

test('creates a hosted Checkout session request with invoice metadata and exact totals', () => {
  const form = createStripeCheckoutParams(invoice, 'https://leadflow.example.workers.dev');
  assert.equal(form.get('mode'), 'payment');
  assert.equal(form.get('customer_email'), 'customer@example.com');
  assert.equal(form.get('metadata[invoice_id]'), 'inv_123');
  assert.equal(form.get('metadata[workspace_id]'), 'ws_123');
  assert.equal(form.get('line_items[0][price_data][unit_amount]'), '20000');
  assert.equal(form.get('line_items[0][quantity]'), '1');
  assert.equal(form.get('line_items[1][price_data][unit_amount]'), '1000');
  assert.equal(form.get('line_items[2][price_data][unit_amount]'), '1365');
  assert.match(form.get('success_url'), /session_id=\{CHECKOUT_SESSION_ID\}/);
});

test('refuses invalid invoice metadata and non-HTTPS origins', () => {
  assert.throws(() => createStripeCheckoutParams(invoice, 'http://localhost:3000'), /HTTPS/);
  assert.throws(() => createStripeCheckoutParams({ ...invoice, items: [] }, 'https://example.com'), /line items/);
});

test('verifies valid Stripe signatures and rejects tampering or stale timestamps', () => {
  const secret = 'whsec_test_only';
  const body = JSON.stringify({ type: 'checkout.session.completed' });
  const timestamp = Math.floor(Date.now() / 1000);
  const digest = createHmac('sha256', secret).update(`${timestamp}.${body}`).digest('hex');
  const signature = `t=${timestamp},v1=${digest}`;
  assert.equal(verifyStripeSignature(body, signature, secret), true);
  assert.equal(verifyStripeSignature(`${body}x`, signature, secret), false);
  assert.equal(verifyStripeSignature(body, `t=${timestamp - 600},v1=${digest}`, secret), false);
});
