# LeadFlow integrations — v0.7.0

## Google Workspace
Google OAuth is workspace-specific. Each workspace owner/admin authorizes a Google account for Gmail sending (`gmail.send`) and Calendar event creation (`calendar.events`). Tokens are encrypted at rest with `INTEGRATION_ENCRYPTION_KEY`. The Integrations screen lists missing Cloudflare configuration. Gmail and Calendar cannot connect until the adult-managed Google OAuth web client is configured with the exact Worker callback and, during testing, the test Google account is added as a test user.

## Stripe Connect
LeadFlow is designed as a SaaS operations layer, not a payment processor or merchant of record. Each business workspace connects its own Stripe Standard account using Connect OAuth. The platform stores the connected account ID encrypted. Checkout Sessions are created on the connected account using the platform key and `Stripe-Account` header, so the business processes and receives its own direct charge. LeadFlow never receives or stores card details. There is no application fee in this version.

The platform Stripe account, Connect configuration, OAuth Client ID, secret key and webhook signing secret must be controlled by an adult/business owner. Each merchant connects their own authorized account. Stripe test/live modes must match. Only connected-account webhook events with a matching account ID, invoice metadata, amount and currency can mark an invoice paid.

## Make / Zapier
New lead records can be forwarded to a workspace-controlled Make or Zapier webhook over HTTPS. Outbound payloads use a field allowlist and HMAC signature. Workspace owners/admins control the webhook URL.

## Not included
QuickBooks, Xero, Square, Jobber, Housecall Pro, recurring invoices, automatic tax determination, refunds/disputes and subscription billing are not live integrations in this release. They should not be advertised as connected or supported until built and tested.
