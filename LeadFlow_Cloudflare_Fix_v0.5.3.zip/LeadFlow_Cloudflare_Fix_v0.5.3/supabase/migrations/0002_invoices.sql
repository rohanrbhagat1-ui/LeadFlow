-- LeadFlow v0.6: workspace-scoped invoices and hosted payment page tokens.
-- Run after 0001_initial.sql in the Supabase SQL Editor.
create table if not exists public.invoices (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  lead_id uuid references public.leads(id) on delete set null,
  invoice_number text not null,
  public_token uuid not null default gen_random_uuid() unique,
  customer_name text not null check (char_length(customer_name) between 1 and 120),
  customer_email text not null check (char_length(customer_email) between 3 and 254),
  currency text not null default 'usd' check (currency = 'usd'),
  items jsonb not null check (jsonb_typeof(items) = 'array'),
  subtotal numeric(12,2) not null check (subtotal >= 0),
  tax_rate numeric(5,2) not null default 0 check (tax_rate between 0 and 25),
  tax_amount numeric(12,2) not null default 0 check (tax_amount >= 0),
  total numeric(12,2) not null check (total > 0),
  notes text check (notes is null or char_length(notes) <= 1500),
  due_date date,
  status text not null default 'draft' check (status in ('draft','sent','paid','void')),
  payment_provider text,
  stripe_checkout_session_id text,
  stripe_payment_intent_id text,
  sent_at timestamptz,
  paid_at timestamptz,
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(workspace_id, invoice_number)
);

create index if not exists invoices_workspace_created_idx
  on public.invoices(workspace_id, created_at desc);
create index if not exists invoices_workspace_status_idx
  on public.invoices(workspace_id, status);

alter table public.invoices enable row level security;
drop policy if exists "members can read workspace invoices" on public.invoices;
create policy "members can read workspace invoices"
  on public.invoices for select to authenticated
  using (public.is_workspace_member(workspace_id));
-- Deliberately no direct insert/update/delete policies. Mutations go through
-- authenticated server routes that verify workspace membership before using
-- the server-only Supabase key. Payment state is changed only by Stripe webhook.


-- Allow each workspace to authorize its own Stripe Connect account.
alter table public.integrations drop constraint if exists integrations_provider_check;
alter table public.integrations add constraint integrations_provider_check
  check (provider in ('google_workspace', 'zapier', 'make', 'stripe'));
