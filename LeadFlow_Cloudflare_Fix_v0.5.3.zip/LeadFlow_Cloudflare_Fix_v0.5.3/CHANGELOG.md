# Changelog

## 0.7.0 — Business workflows and connected payments
- Reworked the dashboard around overview, leads, invoices and integrations.
- Added itemized invoice creation, public invoice pages and print/save-PDF support.
- Added Gmail invoice delivery and a customer-facing payment page.
- Replaced platform-global Stripe Checkout with per-workspace Stripe Connect Standard authorization and direct charges to each connected business account.
- Added connected-account webhook validation for account, mode, invoice, amount and currency.
- Added Stripe disconnect and missing-configuration diagnostics.
- Lead pipeline now advances to quote-sent when an invoice is sent and won after verified payment.
- Added updated invoice migration and deployment instructions.

## 0.6.0 — Initial invoices and hosted checkout
- Added invoice drafts and public invoice pages.
- Added early hosted payment route and webhook verification.

## 0.5.3 — Cloudflare OpenNext deployment foundation
- Added OpenNext Cloudflare adapter configuration and Wrangler settings.
